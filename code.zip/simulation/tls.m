%Updated by Yi He on 21/03/2019

function [b,gamma,ix]=tls(X,y,type,w)

%%% Input arguments
% X: n*p design matrix
% y: n*1 response vector

if nargin<2
    error('Require at least two input arguments')
elseif nargin<3
    type='ridge'; % shrinkage estimator
end
%[n,p]=size(X);
ix=1:size(X,2);
ix(sum(isnan(X))>0)=[];
X=X(:,ix);
[n,p]=size(X);
c=p/n;
if c>=1
    error('the number of variables is too large')
end
[b,~,r]=regress(y,[ones(n,1),X]);
beta_ls=b(2:end); % r is just the residuals
err_var=sum(r.^2)/(n-1-p); % variance of error
tau_sq=var(y)-err_var; % signal length
switch type
    case 'shrinkage'
        if nargin<4
            gamma=c*err_var/((1-c)*tau_sq); % shrinkage factor
            if gamma>0
                beta=beta_ls/(1+gamma);
            else
                beta=zeros(p,1);
            end
        else
            beta=beta_ls/(1+w);
        end
    case 'ridge' % ridge estimator
        S=cov(X);
        if nargin<4
            gamma=c*err_var/tau_sq;
            if gamma>0
                beta=(S+gamma*diag(diag(S)))\(X'*(y-mean(y))/(n-1));
            else
                beta=zeros(p,1);
            end
        else
            beta=(S+w*diag(diag(S)))\(X'*(y-mean(y))/(n-1));
        end
    case 'ols'
        beta=beta_ls;
        gamma=0;
    case 'tik'
        beta=(cov(X)+w)\(X'*(y-mean(y))/(n-1));
    otherwise
        error('Unrecognized type of estimator')
end


alpha=mean(y)-mean(X)*beta;
b=[alpha;beta];


end

