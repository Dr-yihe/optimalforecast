function X = trndstd(nu,arg)
% Simulate standardised t distributed observations

if nu>2
X=trnd(nu,arg);
X=X*sqrt((nu-2)/nu);
else
    error('infinite variance')
end

end

