clear
load calibratedata tau_trimmed signaltonoise
%% Simulation  Set 1: IID
disp('Initializing parameters..')
c=1/3; % concentration ratio
p_all=[30,120,480];  % the set of dimensions
m=100; % number of sample paths
tausq=nanmedian(signaltonoise);
errabs_s=nan(m,numel(p_all)); % relative efficiency of the shrinakge estimator
errabs_r=errabs_s;
reff=nan(m,numel(p_all));
reff_ols=reff;
rng('default')
% generate predictor datasets
Z=trndstd(5,[max(p_all)/c,max(p_all),m]);
e=trndstd(5,[max(p_all)/c,m]);
b=normrnd(0,1,max(p_all),1);
%% Random-effects Model
disp('Estimations started...')
for mix=1:numel(p_all)
    rng(10)
    p=p_all(mix); n=round(p/c);
    Omega_eigvals=quantile(tau_trimmed,linspace(0,1,p));
    Omega_eigvals=Omega_eigvals/mean(Omega_eigvals(:));
    Omega=rMAP(Omega_eigvals');
    Omega_sqrt=sqrtm(Omega);
    beta=sqrt(tausq)*b(1:p)/sqrt(p);
    for i=1:m
        %i
        X=Z(1:n,1:p,i)*Omega_sqrt;
        y=X*beta+e(1:n,i);
        L=@(b)((b(2:end)-beta)'*Omega*(b(2:end)-beta)+b(1)^2); % predictive loss
        %L_ols=L(tls(X,y,'ols'));
        L_s=L(tls(X,y,'shrinkage'));
        L_r=L(tls(X,y,'ridge'));
        L_s_oracle=L(tls(X,y,'shrinkage',(p/n)/((1-p/n)*(beta'*Omega*beta))));
        L_r_oracle=L(tls(X,y,'ridge',(p/n)/(beta'*Omega*beta)));
%         Gamma=diag(std(X));
%         B=corr(X);
%         [~,dhat]=QuESTimate(X/Gamma);[V,~]=eig(B);
%         L_tik=@(d)(L(tls(X,y,'tik',Gamma*(exp(d(1))*eye(p)+exp(d(2))*B+exp(d(3))*(B^2)+exp(d(4))*V*diag(dhat)*V')*Gamma)));
%         [d_opt,L_opt]=fminsearch(L_tik,[log((p/n)/(beta'*Omega*beta)),0,0]);
        errabs_s(i,mix)=abs(L_s./L_s_oracle-1);
        errabs_r(i,mix)=abs(L_r./L_r_oracle-1);
        reff(i,mix)=L_r/L_s;
        reff_ols(i,mix)=L_r/L(tls(X,y,'ols'));
    end
end
%%
disp('Exporting the boxplots in Figures 2 and 3...')
figure
boxplot(errabs_r,{'p=30', 'p=120', 'p=480'})
title('Ridge Estimator')
ylim([0,0.3])
export_fig consistency-ridge-boxplot.eps -transparent

figure
boxplot(errabs_s,{'p=30', 'p=120', 'p=480'})
title('Linear Shrinkage Estimator')
ylim([0,0.3])
export_fig consistency-linear-boxplot.eps -transparent

figure
boxplot(reff,{'p=30', 'p=120', 'p=480'})
title('Ridge/Linear')
ylim([0,1.2])
export_fig convergence-eff-boxplot.eps -transparent
%%
figure
boxplot(reff_ols,{'p=30', 'p=120', 'p=480'})
title('Ridge/OLS')
ylim([0,1.2])
export_fig convergence-eff-ols-boxplot.eps -transparent

