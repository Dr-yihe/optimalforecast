function [R,evals,convergence] = rMAP(eigenval,eps, maxits) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % rMAP: Generate a correlation matrix (R) with a fixed set of 
  %       eigenvalues by the method of alternating projections 
  % Based on the R code by Niel Waller, October 27, 2016
  %
  % Input:
  % eigenval    Desired spectrum of R
  % eps         convergence criterion. Default = 1e-12
  % maxits       Maximum number of iterations of the MAP

  % Output:
  % R           A correlation matrix with the desired spectrum
  % evals       Eigenvalues of R at solution
  % convergence (Logical) TRUE if MAP converged to a feasible solution, 
  %             otherwise FALSE
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%rng('default');

if nargin<3
    maxits=5000;
end
if nargin<2
    eps=10^(-12);
end


Nvar = numel(eigenval);

if abs(sum(eigenval)-Nvar)>eps
    error("Sum of eigenvalues not equal to Number of Variables")
end

M = rand(Nvar,Nvar);
Q = orth(M);

% create a PSD covariance matrix with desired spectrum
  LambdaStar = diag(eigenval);
  
  S.LambdaStar = Q*LambdaStar*Q'; %*% LambdaStar %*% t(Q)
  % enforce symmetry
  S.LambdaStar = 0.5 * (S.LambdaStar + S.LambdaStar');
  
  delta = 1;iter = 0;
  
  while delta>=eps
      % Project onto symmetric matrix with unit diagonals
    Su = S.LambdaStar;
    Su(1:Nvar+1:end)= ones(Nvar,1);
  
  %update eigenvectors
  [Q,D]=eig(Su);
  Lambda=diag(D);
  
  % test convergence
    delta = sqrt(sum((eigenval-Lambda).^2));
    iter = iter + 1;
    if(iter > maxits)
      warning('Failed to converge after maxits iterations');
      delta = 0;
    end  
    
   % Project onto symmetric matrix with given spectrum
    S.LambdaStar = Q*LambdaStar*Q';
    % enforce symmetry
    S.LambdaStar = 0.5 * (S.LambdaStar + S.LambdaStar');
  end
    % at convergence
  R = S.LambdaStar;
  R(1:Nvar+1:end)= ones(Nvar,1);
  
  % check solution feasibility 
  convergence = true;
  if (sum(R(:)>1)>0) || iter==maxits
      convergence = false;
  end
  
  evals=diag(eig(R));
end

