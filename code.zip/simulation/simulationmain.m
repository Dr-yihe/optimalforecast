% load the export_fig package for outputing the figures
addpath('savefig') 


% run the simulations
disp('Simulations started...');
disp('----- Set 1 in the IID model -----');
IID_set1
disp('----- Set 2 in the IID model -----');
IID_set2
disp('----- Set 1 in the AR model -----');
AR_set1
disp('----- Set 2 in the AR model -----');
AR_set2
disp('---------------------------------');
disp('Finished!');
