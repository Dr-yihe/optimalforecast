clc;clear
load dataanalysisdata data
T=size(data,1);

%% Calibriating the spectral distribution
n=360; tau=[];

ypred=nan(T,7);

for t=n+1:T
    t
    % forecasting the t-th period
    X=data((t-n):(t-1),:);
    ix=1:size(X,2);
    ix(sum(isnan(X))>0)=[];
    X=X(:,ix);
    [~,~,tauhat]=QuESTimate(X/diag(std(X)));
    tau=[tau;tauhat];
end
tau_sort=sort(tau);
tau_trimmed=tau_sort(round(0.01*numel(tau)):round(0.99*numel(tau)));
%% Plotting the spectral distribution
f=cdfplot(tau_trimmed);
set(gca, 'XScale', 'log')
set(f,'LineWidth',3,'Color','black')
title('Calibrated Spectral Distribution')
export_fig dataspectraldistribution.eps -transparent

%% Calibrate the signal-to-noise ratio
load dataanalysisdata varts_n360
signaltonoise=varts_n360(:,2)./varts_n360(:,1);
%%
save calibratedata