% 23/03/2019
disp('Data analysis started...')
disp('----- read csv files and clean the data -----')
fredfactors %Step 1 and Step 2 in FRED MATLAB code
INDPRO=importdata('INDPRO.csv',','); % import IP index data
%y=diff(log(INDPRO.data(2:end)));
data_pred=[diff(log(INDPRO.data(3:end))),data]; % combine datasets: the first column is the response vector

%%
disp('----- Rolling window estimations started -----')
disp('Estimations for Lag = 360 months...')
[ypred_n360,err_n360,varts_n360,cts_n360,gammats_n360,ARlag_n360] = RWforecast(data_pred(:,2:end),data_pred(:,1),360);
disp('Estimations for Lag = 240 months...')
[ypred_n240,err_n240,varts_n240,cts_n240,gammats_n240,ARlag_n240] = RWforecast(data_pred(:,2:end),data_pred(:,1),240);
disp('Estimations for Lag = 180 months...')
[ypred_n180,err_n180,varts_n180,cts_n180,gammats_n180,ARlag_n180] = RWforecast(data_pred(:,2:end),data_pred(:,1),180);
%% Plot of the ridge factor
disp('----- Plot the estimated ridge factors -----')
timeix=361:size(data_pred,1);
figure
hold on
plot(dates(timeix),gammats_n360(timeix,2),'k')
plot(dates(timeix),gammats_n240(timeix,2),'k--')
plot(dates(timeix),gammats_n180(timeix,2),'k:')
%ylim([0,1.6])
legend('Window Size=360','Window Size=240','Window Size=180')
title('Ridge Factor')
xlim([dates(361),dates(end)])
box on
%export_fig ridgefactor.eps -transparent
hold off
%%
disp('----- Plot the estimated linear shrinkage factors -----')
figure
hold on
plot(dates(timeix),gammats_n360(timeix,1),'k')
plot(dates(timeix),gammats_n240(timeix,1),'k--')
plot(dates(timeix),gammats_n180(timeix,1),'k:')
%ylim([0,3.5])
legend('Window Size=360','Window Size=240','Window Size=180')
title('Linear Shrinkage Factor')
xlim([dates(361),dates(end)])
box on
%export_fig shrinkagefactor.eps -transparent
hold off
%%

disp('----- Calculating relative predictive losses -----')
relerr=nan(8,3);
relerr(:,1)=nanmean(err_n360.^2)-nanmean(varts_n360(:,1));
relerr(:,2)=nanmean(err_n240.^2)-nanmean(varts_n240(:,1));
relerr(:,3)=nanmean(err_n180.^2)-nanmean(varts_n180(:,1));
relerr=relerr./(ones(size(relerr,1),1)*relerr(1,:));
Method={'Autoregression';'Least-squares';'Linear Shrinkage';'Ridge';...
    'PCA, 1 factor';'PCA, 2 factors';'PCA, 3 factors';'PCA, 4 factors'};
Window360=relerr(:,1);Window240=relerr(:,2);Window180=relerr(:,3);
format bank
T=table(Method,Window360,Window240,Window180)
%%
%save dataanalysisdata