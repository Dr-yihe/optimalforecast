function [ypred,err,varts,cts,gammats,ARlag] = RWforecast(data,response,n)
% data: n*p prediction matrix
% response: is n*1 response vector
% ypred: T*d matrix of the forecasts, d denotes the number of methods
% err: n*d forecast error
% varts: T*2 matrix of noise(first col) and signal (second col)
% cts: T*1 vector of concertartion ratio
% gammats: T*2 matrix of the scalar shrinkage factor (first column) and the
% ridge factor (second column)
% ARLag: T*1 vector of the number of lags for autoregression selected by
% BIC criteria

if size(data,1)~=numel(response)
    error('size of design matrix and response vector does not match')
end
if nargin<2
    error('not enough input arguments')
elseif nargin<3
    n=round(size(data,1)/10);
end

T=size(data,1);ypred=nan(T,8); ARlag=nan(T,1);
varts=nan(T,2);cts=nan(T,1); gammats=nan(T,2);
%% Rolling window with size n=360
for t=n+1:T    % forecasting the t-th period
    X=data((t-n):(t-1),:);
    ix=1:size(X,2);
    ix(sum(isnan(X))>0)=[];
    X=X(:,ix);
    cts(t,1)=size(X,2)/n;
    y=response((t-n):(t-1));
    
    b_ls=regress(y,[ones(n,1),X]);
    varts(t,1)=sum((y-b_ls(1)-X*b_ls(2:end)).^2)/(n-numel(b_ls));
    varts(t,2)=var(y)-varts(t,1);
    [ypred(t,1),ARlag(t)]=ARforecast(y);
    
    [b_s,gammats(t,1)]=tls(X,y,'shrinkage');
    [b_r,gammats(t,2)]=tls(X,y,'ridge');
    
    %imputation of missing values
    xpred=data(t,ix);
    nanix=(1:numel(ix))';
    nanix=nanix(isnan(xpred));
    for i=1:numel(nanix)
        xpred(nanix(i))=ARforecast(X(:,nanix(i)));
    end
    ypred(t,2)=b_ls(1)+xpred*b_ls(2:end);
    ypred(t,3)=b_s(1)+xpred*b_s(2:end);
    ypred(t,4)=b_r(1)+xpred*b_r(2:end);

    for k=1:4
        G=diag(std(X));
        coeff=pca(X/G,'NumComponents',k);
        b_pca=regress(y,[ones(n,1),X/G*coeff]);
        ypred(t,4+k)=b_pca(1)+xpred/G*coeff*b_pca(2:end);
    end
end
err=ypred-response*ones(1,size(ypred,2));

end

