function [f,ix,e] = ARforecast(y,maxLag)
if nargin<2
    maxLag=4;
end

LOGL = zeros(maxLag,1); % Initialize
PQ = zeros(maxLag,1);
fit=cell(maxLag,1);
for p = 1:maxLag
    mod = arima(p,0,0);
    [fit{p},~,logL] = estimate(mod,y,'Display','off');
    LOGL(p) = logL;
    PQ(p) = p;
end
[~,bic] = aicbic(LOGL,PQ+1,100);

[~,ix]=min(bic);

f=fit{ix}.Constant+cell2mat(fit{ix}.AR)*y(end:-1:(end-ix+1));

if nargout>2
e=nan(numel(y),1);
for t=ix+1:numel(e)
    e(t)=y(t)-(fit{ix}.Constant+cell2mat(fit{ix}.AR)*y(t-1:-1:t-ix));
end

end

